#
int main()
{
	printf("Welcome to CMPT 201")
}
